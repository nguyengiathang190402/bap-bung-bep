<label class="label">AMP</label>
<div id="advads-adsense-responsive-amp-inputs">
	<?php esc_html_e( 'Automatically convert AdSense ads into their AMP format', 'advanced-ads' ); ?>
	<p><?php Advanced_Ads_Admin_Upgrades::upgrade_link( null, ADVADS_URL . 'add-ons/responsive-ads/', 'upgrade-ad-edit-adsense-amp' ); ?></p>
</div>
<hr />
