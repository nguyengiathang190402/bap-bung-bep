<div class="notice notice-error advads-admin-notice inline"><p><?php echo wp_kses_post( $text ); ?></p></div>
