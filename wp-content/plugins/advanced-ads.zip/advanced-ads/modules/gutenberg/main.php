<?php

if ( class_exists( 'Advanced_Ads', false ) ) {
	Advanced_Ads_Gutenberg::get_instance();
}